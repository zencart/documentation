<?php
/**
 * @package htmleditors
 * @copyright Copyright 2010 Kuroi Web Design
 * @copyright Copyright 2003-2016 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Author: DrByte  Thu Jan 7 14:19:15 2016 -0500 New in v1.5.5 $
 */

  define('EDITOR_CKEDITOR', 'CKEditor');
