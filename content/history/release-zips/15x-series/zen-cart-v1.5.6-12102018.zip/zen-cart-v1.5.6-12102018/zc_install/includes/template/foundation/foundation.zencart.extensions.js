/*
 * Zen Cart extensions to the Foundation Responsive Library http://foundation.zurb.com
 * @package templates
 * @copyright Copyright 2003-2016 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Author: zcwilt  Wed Sep 23 20:04:38 2015 +0100 New in v1.5.5 $
 */
/*
 * This file initially held additional override functionality that has since been built-in to Foundation 5
 * Keeping the file temporarily in case a need arises for it.
 */
