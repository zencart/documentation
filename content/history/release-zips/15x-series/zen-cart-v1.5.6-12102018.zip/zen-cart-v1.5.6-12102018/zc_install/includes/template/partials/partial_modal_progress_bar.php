<?php
/**
 * @package Installer
 * @copyright Copyright 2003-2016 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: Author: zcwilt  Wed Sep 23 20:04:38 2015 +0100 New in v1.5.5 $
 */
?>
<div id="progress-bar-dialog" class="reveal-modal" data-reveal tabindex="-1">
<div class="modal-header">
<h3 id="dialog-title"></h3>
</div>
<div id="progress-bar-container" class="modal-body">
<div id="progress-bar" class="progress"></div>
</div>
</div>
