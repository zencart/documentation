/*
	This file does not exist.
	If you are looking for the unminified version of jquery.mmenu.min.js,
	have a look at the files jquery.mmenu.oncanvas.js and addons/jquery.mmenu.offcanvas.js
	For complete source files, visit: http://mmenu.frebsite.nl/download.html
*/
console.group( 'jquery.mmenu.js is an empty file.' );
console.error( 'If you are looking for the unminified version of jquery.mmenu.min.js, have a look at the files jquery.mmenu.oncanvas.js and addons/jquery.mmenu.offcanvas.js available at http://mmenu.frebsite.nl/download.html' );
console.groupEnd();