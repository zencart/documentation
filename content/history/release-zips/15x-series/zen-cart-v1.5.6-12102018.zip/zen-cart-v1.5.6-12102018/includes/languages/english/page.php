<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2013 Zen Cart Development Team
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Tue Jan 15 15:50:09 2013 -0500 New in v1.5.2 $
 */

define('ERROR_PAGE_NOT_FOUND', 'Sorry, the page you were attempting to access cannot be found.');
