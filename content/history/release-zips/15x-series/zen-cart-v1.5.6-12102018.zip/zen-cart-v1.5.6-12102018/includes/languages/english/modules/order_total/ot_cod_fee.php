<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2013 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @copyright Portions Copyright (c) 2002 Thomas Plänkers http://www.oscommerce.at
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version GIT: $Id: Author: DrByte  Fri Apr 5 19:06:27 2013 -0400 Modified in v1.5.2 $
 */

  define('MODULE_ORDER_TOTAL_COD_TITLE', 'COD Fee');
  define('MODULE_ORDER_TOTAL_COD_DESCRIPTION', 'COD Fee');
  define('TEXT_INFO_COD_FEES', '<strong>Note:</strong> COD fees may apply');
