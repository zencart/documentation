<?php
/**
 * @package languageDefines
 * @copyright Copyright 2003-2010 Zen Cart Development Team
 * @copyright Portions Copyright 2003 osCommerce
 * @license http://www.zen-cart.com/license/2_0.txt GNU Public License V2.0
 * @version $Id: download.php 15514 2010-02-18 07:27:05Z drbyte $
 */

define('ERROR_CUSTOMER_DOWNLOAD_FAILURE', 'Customer Download Failure');
