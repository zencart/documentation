<?php

require 'vendors/PHPMailer/PHPMailerAutoload.php';